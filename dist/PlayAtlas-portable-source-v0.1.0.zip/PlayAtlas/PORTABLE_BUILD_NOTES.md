# PlayAtlas portable build notes

Generated: 2026-10-04T16:53:29Z
Archive: `PlayAtlas-portable-source-v0.1.0.zip`
Project files included: 133

## What this artifact is

This is a source-first portable archive. It includes the Godot project, rule engines, data, tests, tools, documentation, and any web preview present at build time.

## What this artifact is not

It is not a Windows installer or a claim that the game was launched and manually accepted on Windows. It is not an Android APK and no Android device verification is implied.

## Build host

- OS: Linux-6.18.44-x86_64-with-glibc2.39
- Python: 3.12.14 (main, Aug 25 2026, 14:00:49) [Clang 22.1.3 ]
- Godot executable detected: no

## First run

- Linux/macOS: run `run_qa.sh` for headless rule checks, or open the project with a compatible Godot 4.x editor.
- Windows: run `run_qa.bat` for headless rule checks, or open the project with a compatible Godot 4.x editor.
- Review `reports/qa/qa_report.md` and `GAME_STATUS.md`; entries marked 未测试/待验证 remain unverified.
